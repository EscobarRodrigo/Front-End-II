
/* 

    Boas práticas

        1. Nomeie variáveis, funções e classes.

        2. Divida as responsabilidades em funções.

        3. KISS -> Keep it simple, stupid.

        4. DRY -> Don't repeat yourself.
    
*/